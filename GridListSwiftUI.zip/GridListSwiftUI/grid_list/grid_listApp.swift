//
//  grid_listApp.swift
//  grid_list
//
//  Created by spantar on 2024/12/28.
//

import SwiftUI

@main
struct grid_listApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
