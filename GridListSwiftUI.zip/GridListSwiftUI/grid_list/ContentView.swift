//
//  ContentView.swift
//  grid_list
//
//  Created by spantar on 2024/12/28.
//

import SwiftUI
import SDWebImage
import SDWebImageSwiftUI
import Refresh

struct ContentView: View {
    @ObservedObject var viewModel:ViewModel = ViewModel()
    
    var body: some View {
        ScrollView {
            VStack{
                let gridItem = GridItem(.fixed(100), spacing: 24)
                let gridItem1 = GridItem(.fixed(100), spacing: 24)
                LazyVGrid(columns: [gridItem, gridItem1]) {
                    //main ui part
                    ForEach(viewModel.nfts) { nft in
                        VStack{
                            //TODO: webimage
                            WebImage(url: URL(string: nft.imgUrl))
                                .resizable()
                                .frame(width: 100, height: 100)
                            
                            Spacer().frame(height: 12)
                            Text(nft.name)
                        }
                    }
                }
            }
            RefreshFooter(refreshing: $viewModel.isLoading) {
                viewModel.loadNFTs(requestType: .loadingMore)
            } label: {
                Text("loading more ...")
            }
        }
        .enableRefresh()
        .onAppear {
            viewModel.loadNFTs()
        }
        
    }
}

#Preview {
    ContentView()
}

struct NFT : Identifiable {
    var id:String
    var name:String
    var imgUrl:String
}

enum RequestType {
    case refresh
    case loadingMore
}

class ViewModel : ObservableObject {
    let API = "https://api-mainnet.magiceden.io/idxv2/getListedNftsByCollectionSymbol?collectionSymbol=okay_bears&limit=20"
    
    @Published var nfts:[NFT] = []
    
    @Published var curPage:Int = 0
    @Published var isLoading:Bool = false
    
    public func loadNFTs(requestType:RequestType = .refresh) {
        if requestType == .refresh {
            self.nfts = []
            curPage = 0
        } else {
            isLoading = true
        }
        
        let realApi = API + "&offset=\(curPage)"
        
        
        let url = URL(string: realApi)!
        let request = URLRequest(url: url)
        let session = URLSession.shared.dataTask(with: request) { data, response, error in
            if requestType == .loadingMore {
                self.isLoading = false
                self.curPage += 1
            }
             
            
            //TODO: data parse logic
            guard error == nil else {
                print("[request] error = \(error.debugDescription)")
                return;
            }
            
            guard let data = data else {
                print("[request] error data")
                return
            }
            
            DispatchQueue.main.async {
                
                do {
                    if let dict = try JSONSerialization.jsonObject(with: data) as? [String:Any] {
                        if let results = dict["results"] as? [[String:Any]] {
                            results.forEach { element in
                                let nft = NFT(id: element["id"] as! String, name: element["title"] as! String, imgUrl: element["img"] as! String)
                                self.nfts.append(nft)
                            }
                            print("nft count = \(self.nfts.count)")
                        }
                    }
                } catch {
                    print("[request] data parse error \(error.localizedDescription)")
                }
            }
            
        }
        session.resume()
    }
}
